print("✅ Dashboard smoke: OK (placeholder)")
